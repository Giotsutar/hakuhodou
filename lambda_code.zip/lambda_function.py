import pymysql
import json
import os
import pandas as pd
from sklearn.linear_model import LinearRegression

def lambda_handler(event, context):
    connection = pymysql.connect(
        host=os.environ['DB_HOST'],
        user=os.environ['DB_USER'],
        password=os.environ['DB_PASS'],
        db=os.environ['DB_NAME'],
        cursorclass=pymysql.cursors.DictCursor
    )

    try:
        channel = event["queryStringParameters"].get("channel", "Twitter")
        df = pd.read_sql(
            "SELECT date, impressions, conversions, clicks FROM ad_metrics WHERE channel = %s",
            connection, params=[channel]
        )

        if df.empty or df.shape[0] < 3:
            return {
                "statusCode": 400,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"error": "データが少なすぎます"})
            }

        X = df[["impressions", "conversions"]]
        y = df["clicks"]
        model = LinearRegression().fit(X, y)
        df["predicted_clicks"] = model.predict(X)

        response = {
            "coef": {
                "intercept": model.intercept_,
                "impressions": model.coef_[0],
                "conversions": model.coef_[1]
            },
            "r2": model.score(X, y),
            "data": df.to_dict(orient="records")
        }

        return {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps(response)
        }
    finally:
        connection.close()
